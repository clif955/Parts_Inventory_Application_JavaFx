package controller;

class InitializeTest {

}